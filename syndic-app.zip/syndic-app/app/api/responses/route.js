import { saveResponse } from '../../../lib/db';

export async function POST(request) {
  try {
    const data = await request.json();
    await saveResponse(data);
    return Response.json({ success: true });
  } catch (error) {
    console.error('Save error:', error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}

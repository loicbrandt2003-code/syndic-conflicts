import { getAllResponses, deleteResponse } from '../../../lib/db';

// Vérification du mot de passe admin
function checkAuth(request) {
  const auth = request.headers.get('x-admin-password');
  return auth === process.env.ADMIN_PASSWORD;
}

// GET — récupérer toutes les réponses
export async function GET(request) {
  if (!checkAuth(request)) {
    return Response.json({ error: 'Non autorisé' }, { status: 401 });
  }
  try {
    const responses = await getAllResponses();
    return Response.json({ success: true, responses });
  } catch (error) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}

// DELETE — supprimer une réponse
export async function DELETE(request) {
  if (!checkAuth(request)) {
    return Response.json({ error: 'Non autorisé' }, { status: 401 });
  }
  try {
    const { id } = await request.json();
    await deleteResponse(id);
    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}

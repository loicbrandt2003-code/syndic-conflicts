export const metadata = {
  title: 'Conflits en Copropriété · Étude UNamur',
  description: 'Étude qualitative sur les conflits dans la gestion journalière des syndics',
}

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <head>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>
      </head>
      <body style={{margin:0, padding:0, background:'#0F0F0F', color:'#F0F0F0', fontFamily:"'Montserrat', sans-serif"}}>
        {children}
      </body>
    </html>
  )
}

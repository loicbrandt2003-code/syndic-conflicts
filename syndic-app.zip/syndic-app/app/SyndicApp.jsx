'use client';
import { useState, useEffect, useCallback } from 'react';

// ─── PALETTE ─────────────────────────────────────────────────────────────────
const C = {
  bg:'#0F0F0F', surface:'#161616', card:'#1C1C1C', border:'#2A2A2A',
  accent:'#6DB33F', accentSoft:'#89CC58', red:'#D94F3D',
  gold:'#E8A020', green:'#6DB33F', text:'#F0F0F0',
  muted:'#888888', dim:'#444444',
};

// ─── EMPTY FORM ───────────────────────────────────────────────────────────────
const emptyForm = () => ({
  syndicName:'', years:'',
  conflictTypes:[], conflictTypesOther:'',
  q3:0, q4:0, q5:0, q6:0,
  expectations:[], expectationsOther:'',
  q8:'', agTensions:'',
  agTriggers:[], agTriggersOther:'',
  unjustifiedReproaches:'',
  reproachesFocus:[], reproachesFocusOther:'',
  personalAttack:'', borderlineBehavior:'',
  impactAreas:[],
  conflictCosts:[], conflictCostsOther:'',
  missingTools:[], missingToolsOther:'',
});

// ─── STATS HELPERS ────────────────────────────────────────────────────────────
const avg = (arr, key) => arr.length ? arr.reduce((s,r)=>s+(r[key]||0),0)/arr.length : 0;
const pct = (arr, pred) => arr.length ? Math.round(arr.filter(pred).length/arr.length*100) : 0;
const countValues = (arr, key) => {
  const map = {};
  arr.forEach(r => {
    const v = r[key];
    if (Array.isArray(v)) v.forEach(x => { if(x) map[x]=(map[x]||0)+1; });
    else if (v) map[v]=(map[v]||0)+1;
  });
  return Object.entries(map).sort((a,b)=>b[1]-a[1]);
};

// ─── STYLES ───────────────────────────────────────────────────────────────────
const css = `
  *{box-sizing:border-box;margin:0;padding:0;}
  body{background:${C.bg};color:${C.text};font-family:'Montserrat',sans-serif;min-height:100vh;}
  nav{background:${C.surface};border-bottom:1px solid ${C.border};padding:0 32px;position:sticky;top:0;z-index:200;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;}
  .nav-brand{padding:14px 0;display:flex;align-items:center;gap:14px;}
  .nav-brand-text small{display:block;font-size:10px;color:${C.dim};text-transform:uppercase;letter-spacing:.14em;font-weight:600;}
  .nav-brand-text strong{font-size:15px;font-weight:800;color:${C.text};}
  .nav-brand-text strong span{color:${C.accent};}
  .nav-tabs{display:flex;gap:4px;padding:10px 0;flex-wrap:wrap;}
  .nav-tab{padding:8px 16px;border-radius:10px;border:none;cursor:pointer;background:transparent;color:${C.muted};font-size:13px;font-weight:500;font-family:'Montserrat',sans-serif;transition:all .2s;}
  .nav-tab.active{background:${C.accent};color:#fff;font-weight:700;}
  .nav-tab:hover:not(.active){background:${C.border};color:${C.text};}
  main{max-width:1080px;margin:0 auto;padding:40px 24px 80px;}
  .page{display:none;}
  .page.active{display:block;animation:fadeIn .3s ease;}
  @keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
  .form-wrap{max-width:660px;margin:0 auto;}
  .form-header{margin-bottom:36px;border-left:4px solid ${C.accent};padding-left:16px;}
  .form-header h1{font-size:22px;font-weight:900;line-height:1.3;margin-bottom:10px;letter-spacing:-.02em;}
  .form-header p{color:${C.muted};font-size:14px;line-height:1.7;}
  .progress-bar{display:flex;gap:4px;margin-bottom:10px;}
  .progress-seg{flex:1;height:4px;border-radius:99px;background:${C.border};transition:background .4s;}
  .progress-seg.done{background:${C.accent};}
  .step-label{font-size:11px;color:${C.dim};text-transform:uppercase;letter-spacing:.1em;margin-bottom:4px;}
  .step-title{font-size:20px;font-weight:800;margin-bottom:24px;letter-spacing:-.01em;}
  .form-card{background:${C.card};border:1px solid ${C.border};border-radius:20px;padding:28px;margin-bottom:24px;}
  .q-label{font-size:14px;color:${C.accentSoft};font-weight:600;margin-bottom:14px;line-height:1.5;}
  .q-block{margin-bottom:28px;}
  .q-block:last-child{margin-bottom:0;}
  .radio-group,.check-group{display:flex;flex-direction:column;gap:8px;}
  .choice-label{display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 14px;border-radius:10px;background:transparent;border:1px solid ${C.border};color:${C.muted};font-size:14px;transition:all .2s;user-select:none;}
  .choice-label:hover{border-color:${C.accent};color:${C.text};}
  .choice-label input{accent-color:${C.accent};}
  .choice-label.selected{background:#6DB33F22;border-color:${C.accent};color:${C.text};}
  .other-row{display:flex;align-items:center;gap:10px;}
  .other-input{flex:1;background:${C.border};border:1px solid ${C.border};border-radius:8px;padding:8px 12px;color:${C.text};font-size:13px;font-family:'Montserrat',sans-serif;outline:none;}
  .other-input:focus{border-color:${C.accent};}
  .likert{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
  .likert-btn{width:46px;height:46px;border-radius:12px;border:2px solid transparent;background:${C.border};color:${C.muted};font-weight:700;font-size:16px;cursor:pointer;transition:all .2s;font-family:'Montserrat',sans-serif;}
  .likert-btn:hover{border-color:#ffffff44;color:${C.text};}
  .likert-btn.sel{transform:scale(1.12);color:#fff;border-color:transparent;}
  .likert-hint{font-size:11px;color:${C.dim};margin-left:6px;}
  .form-nav{display:flex;justify-content:space-between;}
  .btn{padding:12px 26px;border-radius:12px;border:none;cursor:pointer;font-weight:700;font-size:14px;font-family:'Montserrat',sans-serif;transition:all .2s;}
  .btn-ghost{background:transparent;border:1px solid ${C.border};color:${C.muted};}
  .btn-ghost:hover:not(:disabled){color:${C.text};border-color:${C.muted};}
  .btn-ghost:disabled{opacity:.3;cursor:default;}
  .btn-primary{background:${C.accent};color:#fff;}
  .btn-primary:hover{background:${C.accentSoft};}
  .btn-success{background:${C.green};color:#0A2820;}
  .success-screen{text-align:center;padding:80px 20px;}
  .success-screen .icon{font-size:64px;margin-bottom:20px;}
  .success-screen h2{font-size:28px;font-weight:900;color:${C.green};margin-bottom:10px;}
  .success-screen p{color:${C.muted};}
  .dash-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:36px;flex-wrap:wrap;gap:16px;}
  .dash-header h1{font-size:24px;font-weight:900;letter-spacing:-.02em;}
  .dash-header p{color:${C.muted};font-size:13px;margin-top:4px;}
  .btn-outline{background:transparent;border:1px solid ${C.border};color:${C.text};font-size:13px;}
  .btn-outline:hover{border-color:${C.accent};}
  .kpi-banner{background:linear-gradient(135deg,#6DB33F22,${C.card});border:1px solid #6DB33F44;border-radius:20px;padding:28px 32px;margin-bottom:40px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:20px;}
  .kpi-main small{font-size:11px;color:${C.muted};text-transform:uppercase;letter-spacing:.1em;}
  .kpi-main .big-num{font-size:56px;font-weight:900;color:${C.accent};line-height:1;}
  .kpi-main span{font-size:13px;color:${C.dim};}
  .kpi-pills{display:flex;gap:28px;flex-wrap:wrap;}
  .kpi-pill{text-align:center;}
  .kpi-pill .val{font-size:30px;font-weight:800;}
  .kpi-pill .lbl{font-size:11px;color:${C.muted};max-width:90px;line-height:1.3;}
  .section{margin-bottom:44px;}
  .section-head{display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:12px;border-bottom:1px solid ${C.border};}
  .section-bar{width:4px;height:24px;border-radius:99px;}
  .section-head h3{font-size:16px;font-weight:800;letter-spacing:-.01em;}
  .card-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(195px,1fr));gap:14px;margin-bottom:24px;}
  .stat-card{background:${C.card};border:1px solid ${C.border};border-radius:12px;padding:18px 20px;border-left:3px solid ${C.accent};}
  .stat-card small{font-size:11px;color:${C.muted};text-transform:uppercase;letter-spacing:.07em;display:block;margin-bottom:8px;}
  .stat-card .val{font-size:30px;font-weight:800;}
  .stat-card .sub{font-size:11px;color:${C.dim};margin-top:4px;}
  .stat-card .ico{float:right;font-size:26px;opacity:.6;}
  .hbar{display:flex;flex-direction:column;gap:10px;}
  .hbar-labels{display:flex;justify-content:space-between;margin-bottom:4px;}
  .hbar-labels span:first-child{font-size:13px;color:${C.text};}
  .hbar-labels span:last-child{font-size:13px;font-weight:700;}
  .hbar-track{background:${C.border};border-radius:99px;height:7px;overflow:hidden;}
  .hbar-fill{height:100%;border-radius:99px;transition:width .8s cubic-bezier(.4,0,.2,1);}
  .likert-summary{display:flex;flex-direction:column;gap:14px;margin-bottom:24px;}
  .lscore-row{display:flex;justify-content:space-between;align-items:center;gap:12px;}
  .lscore-label{font-size:13px;color:${C.text};flex:1;}
  .lscore-right{display:flex;align-items:center;gap:10px;}
  .lscore-bar{width:90px;height:8px;background:${C.border};border-radius:99px;overflow:hidden;}
  .lscore-fill{height:100%;border-radius:99px;transition:width .6s;}
  .lscore-val{font-weight:700;font-size:15px;min-width:28px;text-align:right;}
  .insight-box{background:#3ECFB211;border:1px solid #3ECFB233;border-radius:14px;padding:20px;margin-top:20px;}
  .insight-box strong{color:${C.green};font-size:14px;display:block;margin-bottom:8px;}
  .insight-box p{color:${C.text};font-size:14px;line-height:1.7;}
  .empty-state{text-align:center;padding:80px 20px;}
  .empty-state .icon{font-size:48px;margin-bottom:16px;}
  .empty-state h2{color:${C.muted};font-size:22px;font-weight:800;margin-bottom:8px;}
  .empty-state p{color:${C.dim};font-size:14px;margin-bottom:24px;}
  .table-wrap{background:${C.card};border:1px solid ${C.border};border-radius:16px;overflow:auto;}
  table{width:100%;border-collapse:collapse;font-size:12px;}
  thead th{padding:12px 14px;background:${C.card};color:${C.muted};text-align:left;border-bottom:1px solid ${C.border};white-space:nowrap;}
  tbody tr{border-bottom:1px solid ${C.border};transition:background .15s;}
  tbody tr:hover{background:${C.border};}
  tbody td{padding:9px 14px;color:${C.text};}
  .tag{display:inline-block;border-radius:6px;padding:2px 10px;font-size:11px;font-weight:600;letter-spacing:.04em;}
  .modal-overlay{display:none;position:fixed;inset:0;z-index:999;background:rgba(0,0,0,.75);backdrop-filter:blur(6px);align-items:center;justify-content:center;}
  .modal-overlay.open{display:flex;}
  .modal-box{background:${C.card};border:1px solid ${C.border};border-radius:20px;padding:40px 36px;width:100%;max-width:400px;border-top:3px solid ${C.accent};}
  .modal-input{width:100%;background:${C.border};border:1px solid ${C.dim};border-radius:10px;padding:12px 16px;color:${C.text};font-size:15px;font-family:'Montserrat',sans-serif;outline:none;margin-bottom:14px;letter-spacing:.1em;}
  .modal-input:focus{border-color:${C.accent};}
  .admin-badge{display:inline-flex;align-items:center;gap:6px;background:#6DB33F22;border:1px solid #6DB33F55;border-radius:8px;padding:4px 12px;font-size:11px;font-weight:700;color:${C.accent};letter-spacing:.06em;cursor:pointer;}
  .loading-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:500;display:flex;align-items:center;justify-content:center;}
  .loading-spinner{width:40px;height:40px;border:3px solid ${C.border};border-top-color:${C.accent};border-radius:50%;animation:spin .7s linear infinite;}
  @keyframes spin{to{transform:rotate(360deg)}}
  @media(max-width:600px){nav{padding:0 16px;}main{padding:24px 16px 60px;}.kpi-main .big-num{font-size:40px;}}
`;

// ─── STEPS CONFIG ─────────────────────────────────────────────────────────────
const STEP_TITLES = [
  'Profil syndic','Types de conflits','Perception des copropriétaires',
  'Attentes & Besoins','Assemblées Générales','Reproches & Ressenti','Impact & Besoins non adressés'
];

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────
export default function SyndicApp() {
  const [tab, setTab] = useState('form');
  const [step, setStep] = useState(0);
  const [form, setForm] = useState(emptyForm());
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [responses, setResponses] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [pendingTab, setPendingTab] = useState(null);
  const [pwdInput, setPwdInput] = useState('');
  const [pwdError, setPwdError] = useState('');
  const [loading, setLoading] = useState(false);
  const [adminPwd, setAdminPwd] = useState('');

  const setF = (key, val) => setForm(f => ({...f, [key]: val}));
  const toggleArr = (key, val) => setForm(f => {
    const arr = f[key]||[];
    return {...f, [key]: arr.includes(val) ? arr.filter(x=>x!==val) : [...arr,val]};
  });

  // Load admin password from env via a small endpoint
  const fetchResponses = useCallback(async (pwd) => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin', { headers: { 'x-admin-password': pwd } });
      if (res.ok) {
        const data = await res.json();
        setResponses(data.responses || []);
      }
    } catch(e) { console.error(e); }
    setLoading(false);
  }, []);

  // ── ADMIN LOGIN ──────────────────────────────────────────────────────────────
  const handleAdminLogin = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin', { headers: { 'x-admin-password': pwdInput } });
      if (res.ok) {
        const data = await res.json();
        setIsAdmin(true);
        setAdminPwd(pwdInput);
        setResponses(data.responses || []);
        setShowLogin(false);
        setPwdError('');
        if (pendingTab) { setTab(pendingTab); setPendingTab(null); }
      } else {
        setPwdError('❌ Mot de passe incorrect.');
        setPwdInput('');
      }
    } catch(e) {
      setPwdError('❌ Erreur de connexion.');
    }
    setLoading(false);
  };

  const handleAdminLogout = () => {
    if (!confirm('Se déconnecter de l\'administration ?')) return;
    setIsAdmin(false);
    setAdminPwd('');
    setResponses([]);
    setTab('form');
  };

  const requireAdmin = (t) => {
    if (isAdmin) { setTab(t); fetchResponses(adminPwd); return; }
    setPendingTab(t);
    setPwdInput('');
    setPwdError('');
    setShowLogin(true);
  };

  // ── SUBMIT FORM ──────────────────────────────────────────────────────────────
  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const res = await fetch('/api/responses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        setSubmitted(true);
        setForm(emptyForm());
        setStep(0);
        setTimeout(() => setSubmitted(false), 3000);
      } else {
        alert('Erreur lors de l\'enregistrement. Veuillez réessayer.');
      }
    } catch(e) {
      alert('Erreur réseau. Veuillez réessayer.');
    }
    setSubmitting(false);
  };

  // ── DELETE RESPONSE ──────────────────────────────────────────────────────────
  const handleDelete = async (id, name) => {
    if (!confirm(`Supprimer la réponse de "${name||'Anonyme'}" ?`)) return;
    setLoading(true);
    try {
      await fetch('/api/admin', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': adminPwd },
        body: JSON.stringify({ id }),
      });
      setResponses(r => r.filter(x => x.id !== id));
    } catch(e) { alert('Erreur lors de la suppression.'); }
    setLoading(false);
  };

  // ── CSV EXPORT ────────────────────────────────────────────────────────────────
  const exportCSV = () => {
    if (!responses.length) return;
    const keys = Object.keys(responses[0]);
    const header = keys.join(';');
    const rows = responses.map(r =>
      keys.map(k => {
        const v = r[k];
        return Array.isArray(v) ? `"${v.join(', ')}"` : `"${v||''}"`;
      }).join(';')
    );
    const csv = '\uFEFF' + [header,...rows].join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));
    a.download = 'syndic_conflits.csv';
    a.click();
  };

  // ── RENDER FORM ELEMENTS ─────────────────────────────────────────────────────
  const RadioGroup = ({name, options}) => (
    <div className="radio-group">
      {options.map(v => (
        <label key={v} className={`choice-label ${form[name]===v?'selected':''}`}
          onClick={() => setF(name, v)}>
          <input type="radio" readOnly checked={form[name]===v}/> {v}
        </label>
      ))}
    </div>
  );

  const CheckGroup = ({name, options, otherKey}) => {
    const arr = form[name]||[];
    return (
      <div className="check-group">
        {options.map(v => (
          <label key={v} className={`choice-label ${arr.includes(v)?'selected':''}`}
            onClick={() => toggleArr(name, v)}>
            <input type="checkbox" readOnly checked={arr.includes(v)}/> {v}
          </label>
        ))}
        {otherKey && (
          <div className="other-row">
            <label className={`choice-label ${arr.includes('Autre')?'selected':''}`}
              onClick={() => toggleArr(name,'Autre')} style={{whiteSpace:'nowrap'}}>
              <input type="checkbox" readOnly checked={arr.includes('Autre')}/> Autre :
            </label>
            <input className="other-input"
              placeholder="Précisez..."
              value={form[otherKey]||''}
              onChange={e => setF(otherKey, e.target.value)}
              onClick={e => e.stopPropagation()}
              style={{opacity: arr.includes('Autre')?1:.4}}
            />
          </div>
        )}
      </div>
    );
  };

  const LikertQ = ({field, label}) => {
    const colors = ['#D94F3D','#E8975A','#E8A020','#7ECF5B','#6DB33F'];
    return (
      <div className="q-block">
        <div className="q-label">{label}</div>
        <div className="likert">
          {[1,2,3,4,5].map(n => (
            <button key={n} className={`likert-btn ${form[field]===n?'sel':''}`}
              style={form[field]===n?{background:colors[n-1]}:{}}
              onClick={() => setF(field, n)}>{n}</button>
          ))}
          <span className="likert-hint">1 = Pas du tout d'accord · 5 = Totalement d'accord</span>
        </div>
      </div>
    );
  };

  // ── STEPS ─────────────────────────────────────────────────────────────────────
  const steps = [
    <div key="s0" className="form-card">
      <div className="q-block">
        <div className="q-label">Q0 — Nom de votre société de syndic</div>
        <input className="other-input" style={{width:'100%',marginTop:4,opacity:1}}
          placeholder="Ex: Syndic Dupont & Associés..."
          value={form.syndicName}
          onChange={e => setF('syndicName', e.target.value)}/>
      </div>
      <div className="q-label">Q1 — Depuis combien d'années exercez-vous en tant que syndic ?</div>
      <RadioGroup name="years" options={['Moins de 5 ans','5-10 ans','+ 10 ans']}/>
    </div>,

    <div key="s1" className="form-card">
      <div className="q-label">Q2 — Quels types de conflits rencontrez-vous le plus souvent ?</div>
      <CheckGroup name="conflictTypes" otherKey="conflictTypesOther" options={[
        'Entre copropriétaires (voisinage, nuisances, incivilités)',
        'Entre copropriétaires et syndic',
        'Entre copropriétaires et prestataires (plombier, peintre, chauffagiste...)'
      ]}/>
    </div>,

    <div key="s2" className="form-card">
      <LikertQ field="q3" label="Q3 — Les copropriétaires expriment clairement leur véritable besoin."/>
      <LikertQ field="q4" label="Q4 — Les demandes formulées ne correspondent pas toujours au besoin réel."/>
      <LikertQ field="q5" label="Q5 — Les copropriétaires cherchent avant tout à être écoutés et pris en charge."/>
      <LikertQ field="q6" label="Q6 — Les copropriétaires attendent principalement une solution immédiate."/>
    </div>,

    <div key="s3" className="form-card">
      <div className="q-block">
        <div className="q-label">Q7 — Les copropriétaires attendent principalement :</div>
        <CheckGroup name="expectations" otherKey="expectationsOther" options={[
          'Une solution rapide','Une reconnaissance de leur problème',
          'Une écoute attentive','Une justification rationnelle'
        ]}/>
      </div>
      <div className="q-block">
        <div className="q-label">Q8 — Un conflit s'est-il déjà envenimé parce qu'un copropriétaire a mal exprimé son besoin ?</div>
        <RadioGroup name="q8" options={['Oui','Non']}/>
      </div>
    </div>,

    <div key="s4" className="form-card">
      <div className="q-block">
        <div className="q-label">Q9 — Les Assemblées Générales sont-elles une source importante de tensions ?</div>
        <RadioGroup name="agTensions" options={['Rarement','Occasionnellement','Fréquemment','Presque toujours']}/>
      </div>
      <div className="q-block">
        <div className="q-label">Q10 — Qu'est-ce qui déclenche le plus de tensions en AG ?</div>
        <CheckGroup name="agTriggers" otherKey="agTriggersOther" options={[
          'Travaux','Charges','Confiance envers le syndic','Communication','Décisions mal comprises','Durée'
        ]}/>
      </div>
    </div>,

    <div key="s5" className="form-card">
      <div className="q-block">
        <div className="q-label">Q11 — Vous arrive-t-il de recevoir des reproches que vous estimez injustifiés ?</div>
        <RadioGroup name="unjustifiedReproaches" options={['Jamais','Parfois','Fréquemment','Presque toujours']}/>
      </div>
      <div className="q-block">
        <div className="q-label">Q12 — Ces reproches portent principalement sur :</div>
        <CheckGroup name="reproachesFocus" otherKey="reproachesFocusOther" options={[
          'Votre temps de réaction','Votre disponibilité','Votre communication',
          'La transparence','Le manque de solutions','La procédure en elle-même'
        ]}/>
      </div>
      <div className="q-block">
        <div className="q-label">Q13 — Vous arrive-t-il de vous sentir personnellement attaqué(e) ?</div>
        <RadioGroup name="personalAttack" options={['Oui','Non']}/>
      </div>
      <div className="q-block">
        <div className="q-label">Q14 — Avez-vous déjà vécu des comportements à la limite de la correction ?</div>
        <RadioGroup name="borderlineBehavior" options={['Oui','Non']}/>
      </div>
    </div>,

    <div key="s6" className="form-card">
      <div className="q-block">
        <div className="q-label">Q15 — Les conflits impactent :</div>
        <CheckGroup name="impactAreas" otherKey={null} options={[
          'Votre charge mentale','La motivation de votre équipe',
          'La relation client','La rentabilité','Votre image'
        ]}/>
      </div>
      <div className="q-block">
        <div className="q-label">Q16 — Les conflits génèrent souvent :</div>
        <CheckGroup name="conflictCosts" otherKey="conflictCostsOther" options={[
          'Des heures non facturables','Des frais juridiques','Des tensions internes','Des pertes de clients'
        ]}/>
      </div>
      <div className="q-block">
        <div className="q-label">Q17 — Qu'est-ce qui vous manque pour mieux gérer les conflits ?</div>
        <CheckGroup name="missingTools" otherKey="missingToolsOther" options={[
          'Du temps','Une procédure clairement définie','Des outils structurés',
          'Des connaissances en gestion de conflits','Un conciliateur'
        ]}/>
      </div>
    </div>,
  ];

  // ── DASHBOARD ─────────────────────────────────────────────────────────────────
  const n = responses.length;
  const pctAttack   = pct(responses, r=>r.personalAttack==='Oui');
  const pctBorder   = pct(responses, r=>r.borderlineBehavior==='Oui');
  const pctBadExpr  = pct(responses, r=>r.q8==='Oui');
  const pctConc     = pct(responses, r=>(r.missingTools||[]).includes('Un conciliateur'));
  const pctProc     = pct(responses, r=>(r.missingTools||[]).includes('Une procédure clairement définie'));
  const pctKnow     = pct(responses, r=>(r.missingTools||[]).includes('Des connaissances en gestion de conflits'));
  const impactTop2  = countValues(responses,'impactAreas').slice(0,2).map(([l])=>l.toLowerCase());

  const HBar = ({data, color}) => {
    if (!data.length) return <p style={{color:C.dim,fontSize:13}}>Pas encore de données.</p>;
    return (
      <div className="hbar">
        {data.map(([label, count]) => {
          const p = n ? Math.round(count/n*100) : 0;
          return (
            <div key={label}>
              <div className="hbar-labels"><span>{label}</span><span style={{color}}>{p}%</span></div>
              <div className="hbar-track"><div className="hbar-fill" style={{width:`${p}%`,background:color}}/></div>
            </div>
          );
        })}
      </div>
    );
  };

  const LScoreRow = ({label, val}) => {
    const p = (val/5)*100;
    const color = p<40?C.red:p<70?C.gold:C.green;
    return (
      <div className="lscore-row">
        <span className="lscore-label">{label}</span>
        <div className="lscore-right">
          <div className="lscore-bar"><div className="lscore-fill" style={{width:`${p}%`,background:color}}/></div>
          <span className="lscore-val" style={{color}}>{val.toFixed(1)}</span>
        </div>
      </div>
    );
  };

  const StatCard = ({label, value, icon, color, sub}) => (
    <div className="stat-card" style={{borderLeftColor:color}}>
      <span className="ico">{icon}</span>
      <small>{label}</small>
      <div className="val" style={{color}}>{value}</div>
      {sub && <div className="sub">{sub}</div>}
    </div>
  );

  const Section = ({title, color, children}) => (
    <div className="section">
      <div className="section-head">
        <div className="section-bar" style={{background:color}}/>
        <h3>{title}</h3>
      </div>
      {children}
    </div>
  );

  // ── RENDER ────────────────────────────────────────────────────────────────────
  return (
    <>
      <style>{css}</style>
      {loading && (
        <div className="loading-overlay">
          <div className="loading-spinner"/>
        </div>
      )}

      {/* NAV */}
      <nav>
        <div className="nav-brand">
          <div className="nav-brand-text">
            <small>Étude qualitative · UNamur</small>
            <strong>Conflits en copropriété <span>· Syndics</span></strong>
          </div>
        </div>
        <div className="nav-tabs">
          <button className={`nav-tab ${tab==='form'?'active':''}`} onClick={()=>setTab('form')}>
            📝 Questionnaire
          </button>
          <button className={`nav-tab ${tab==='dashboard'?'active':''}`} onClick={()=>requireAdmin('dashboard')}>
            📊 Analyse ({n}) {!isAdmin&&'🔒'}
          </button>
          <button className={`nav-tab ${tab==='data'?'active':''}`} onClick={()=>requireAdmin('data')}>
            🗃️ Données {!isAdmin&&'🔒'}
          </button>
          {isAdmin && (
            <span className="admin-badge" onClick={handleAdminLogout}>
              🛡️ Admin · Déconnexion
            </span>
          )}
        </div>
      </nav>

      <main>
        {/* ── QUESTIONNAIRE ── */}
        {tab==='form' && (
          <div className="form-wrap">
            {submitted ? (
              <div className="success-screen">
                <div className="icon">✅</div>
                <h2>Réponse enregistrée !</h2>
                <p>Merci pour votre participation à cette étude.</p>
              </div>
            ) : (
              <>
                <div className="form-header">
                  <h1>Les conflits dans la gestion journalière d'un syndic</h1>
                  <p>Questionnaire destiné aux professionnels de la gestion de copropriété.</p>
                </div>
                {/* Progress */}
                <div className="progress-bar">
                  {STEP_TITLES.map((_,i) => (
                    <div key={i} className={`progress-seg ${i<=step?'done':''}`}/>
                  ))}
                </div>
                <div className="step-label">Étape {step+1} / {STEP_TITLES.length}</div>
                <div className="step-title">{STEP_TITLES[step]}</div>
                {steps[step]}
                <div className="form-nav" style={{marginTop:24}}>
                  <button className="btn btn-ghost" disabled={step===0} onClick={()=>setStep(s=>s-1)}>← Précédent</button>
                  {step < STEP_TITLES.length-1
                    ? <button className="btn btn-primary" onClick={()=>setStep(s=>s+1)}>Suivant →</button>
                    : <button className="btn btn-success" onClick={handleSubmit} disabled={submitting}>
                        {submitting ? 'Enregistrement...' : '✓ Soumettre'}
                      </button>
                  }
                </div>
              </>
            )}
          </div>
        )}

        {/* ── DASHBOARD ── */}
        {tab==='dashboard' && isAdmin && (
          <>
            <div className="dash-header">
              <div><h1>Tableau de bord analytique</h1><p>{n} réponse{n>1?'s':''} · Base de données</p></div>
              <button className="btn btn-outline" onClick={exportCSV}>⬇ Exporter CSV</button>
            </div>

            {n===0 ? (
              <div className="empty-state">
                <div className="icon">📭</div>
                <h2>Aucune réponse encore</h2>
                <p>Les réponses apparaîtront ici dès que des syndics auront rempli le questionnaire.</p>
              </div>
            ) : (
              <>
                {/* KPI Banner */}
                <div className="kpi-banner">
                  <div className="kpi-main">
                    <small>Répondants</small>
                    <div className="big-num">{n}</div>
                    <span>syndics interrogés</span>
                  </div>
                  <div className="kpi-pills">
                    {[
                      {v:`${pctAttack}%`,l:'Se sentent attaqués',c:C.red},
                      {v:`${pctBorder}%`,l:'Comportements limites',c:C.gold},
                      {v:`${pctBadExpr}%`,l:'Besoin mal exprimé',c:C.accentSoft},
                      {v:`${pctConc}%`,l:'Veulent un conciliateur',c:C.green},
                    ].map(({v,l,c})=>(
                      <div key={l} className="kpi-pill">
                        <div className="val" style={{color:c}}>{v}</div>
                        <div className="lbl">{l}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <Section title="1. Profil des répondants" color={C.accentSoft}>
                  <div style={{display:'flex',flexWrap:'wrap',gap:8,marginBottom:20}}>
                    {responses.map((r,i)=>(
                      <span key={i} style={{background:C.border,borderRadius:8,padding:'4px 12px',fontSize:12,color:C.accentSoft}}>
                        {r.syndicName||`Anonyme #${i+1}`}
                      </span>
                    ))}
                  </div>
                  <HBar data={countValues(responses,'years')} color={C.accentSoft}/>
                </Section>

                <Section title="2. Principales sources de conflits" color={C.red}>
                  <HBar data={countValues(responses,'conflictTypes')} color={C.red}/>
                  <p style={{fontSize:13,color:C.muted,margin:'20px 0 12px'}}>🏛️ Fréquence des tensions en AG</p>
                  <HBar data={countValues(responses,'agTensions')} color={C.gold}/>
                  <p style={{fontSize:13,color:C.muted,margin:'20px 0 12px'}}>⚡ Déclencheurs en AG</p>
                  <HBar data={countValues(responses,'agTriggers')} color={C.gold}/>
                </Section>

                <Section title="3. Comment ces conflits sont gérés aujourd'hui" color={C.gold}>
                  <p style={{fontSize:13,color:C.muted,marginBottom:16}}>Alignement perception / réalité (échelle 1–5)</p>
                  <div className="likert-summary">
                    <LScoreRow label="Clarté d'expression des besoins (Q3)" val={avg(responses,'q3')}/>
                    <LScoreRow label="Décalage demande / besoin réel (Q4)" val={avg(responses,'q4')}/>
                    <LScoreRow label="Besoin d'écoute avant tout (Q5)" val={avg(responses,'q5')}/>
                    <LScoreRow label="Attente d'une solution immédiate (Q6)" val={avg(responses,'q6')}/>
                  </div>
                  <p style={{fontSize:13,color:C.muted,marginBottom:12}}>Fréquence des reproches injustifiés</p>
                  <HBar data={countValues(responses,'unjustifiedReproaches')} color={C.red}/>
                  <p style={{fontSize:13,color:C.muted,margin:'20px 0 12px'}}>Portée des reproches</p>
                  <HBar data={countValues(responses,'reproachesFocus')} color={C.gold}/>
                </Section>

                <Section title="4. Conséquences sur le travail des syndics" color={C.red}>
                  <div className="card-grid">
                    <StatCard label="Se sentent attaqués" value={`${pctAttack}%`} icon="😤" color={C.red} sub="des répondants"/>
                    <StatCard label="Comportements limites" value={`${pctBorder}%`} icon="⚠️" color={C.gold} sub="des répondants"/>
                    <StatCard label="Besoin mal exprimé" value={`${pctBadExpr}%`} icon="💬" color={C.accentSoft} sub="ont répondu Oui"/>
                  </div>
                  <p style={{fontSize:13,color:C.muted,marginBottom:12}}>Domaines impactés</p>
                  <HBar data={countValues(responses,'impactAreas')} color={C.red}/>
                  <p style={{fontSize:13,color:C.muted,margin:'20px 0 12px'}}>Coûts générés</p>
                  <HBar data={countValues(responses,'conflictCosts')} color={C.gold}/>
                </Section>

                <Section title="5. Besoins peu ou mal adressés" color={C.green}>
                  <HBar data={countValues(responses,'missingTools')} color={C.green}/>
                  <div className="card-grid" style={{marginTop:24}}>
                    <StatCard label="Souhaitent un conciliateur" value={`${pctConc}%`} icon="🤝" color={C.green} sub="besoin clé"/>
                    <StatCard label="Manque de procédure" value={`${pctProc}%`} icon="📋" color={C.accentSoft} sub="besoin structurel"/>
                    <StatCard label="Manque de formation" value={`${pctKnow}%`} icon="📚" color={C.gold} sub="besoin de compétences"/>
                  </div>
                  <p style={{fontSize:13,color:C.muted,marginBottom:12}}>Attentes des copropriétaires</p>
                  <HBar data={countValues(responses,'expectations')} color={C.green}/>
                  <div className="insight-box">
                    <strong>💡 Insight principal</strong>
                    <p>{pctConc>50
                      ?`Plus de la moitié des syndics (${pctConc}%) expriment le besoin d'un conciliateur externe — signal fort pour la pertinence d'un service de médiation.`
                      :`${pctConc}% des répondants mentionnent le besoin d'un conciliateur.`}
                      {impactTop2.length?` Les conflits impactent en priorité : ${impactTop2.join(' et ')}.`:''}
                    </p>
                  </div>
                </Section>
              </>
            )}
          </>
        )}

        {/* ── DONNÉES BRUTES ── */}
        {tab==='data' && isAdmin && (
          <>
            <div className="dash-header">
              <div><h1>Données brutes</h1><p>{n} réponse{n>1?'s':''} en base de données</p></div>
              <button className="btn btn-outline" onClick={exportCSV}>⬇ Exporter CSV</button>
            </div>
            <div className="table-wrap">
              {!n ? (
                <p style={{padding:40,color:C.muted,textAlign:'center'}}>Aucune donnée pour l'instant.</p>
              ) : (
                <table>
                  <thead>
                    <tr>
                      {['#','Date','Syndic','Exp.','Types conflits','Q3','Q4','Q5','Q6','AG','Attaqué','Limites',''].map(h=>(
                        <th key={h}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {responses.map((r,i) => {
                      const sc = v => ({color: v>=4?C.green:v>=3?C.gold:C.red, fontWeight:700, textAlign:'center'});
                      const tag = (v) => (
                        <span className="tag" style={{background:v==='Oui'?'#D94F3D22':'#6DB33F22',color:v==='Oui'?C.red:C.green}}>
                          {v||'—'}
                        </span>
                      );
                      return (
                        <tr key={r.id}>
                          <td style={{color:C.dim}}>{i+1}</td>
                          <td style={{color:C.muted,fontSize:11}}>{r.createdAt?new Date(r.createdAt).toLocaleDateString('fr-BE'):'—'}</td>
                          <td style={{fontWeight:600,color:C.accentSoft}}>{r.syndicName||'—'}</td>
                          <td>{r.years||'—'}</td>
                          <td style={{maxWidth:180}}>{(r.conflictTypes||[]).join(', ').substring(0,55)||'—'}</td>
                          {['q3','q4','q5','q6'].map(k=><td key={k} style={sc(r[k])}>{r[k]||'—'}</td>)}
                          <td>{r.agTensions||'—'}</td>
                          <td>{tag(r.personalAttack)}</td>
                          <td>{tag(r.borderlineBehavior)}</td>
                          <td>
                            <button onClick={()=>handleDelete(r.id,r.syndicName)}
                              style={{background:'#D94F3D22',border:'1px solid #D94F3D44',color:C.red,borderRadius:8,padding:'4px 10px',cursor:'pointer',fontSize:12,fontFamily:'Montserrat,sans-serif'}}>
                              🗑
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </>
        )}
      </main>

      {/* LOGIN MODAL */}
      <div className={`modal-overlay ${showLogin?'open':''}`}>
        <div className="modal-box">
          <div style={{fontSize:36,marginBottom:12}}>🔐</div>
          <h2 style={{fontSize:20,fontWeight:800,marginBottom:6}}>Accès administrateur</h2>
          <p style={{fontSize:13,color:C.muted,marginBottom:24}}>Cette section est réservée à l'administrateur de l'étude.</p>
          <input className="modal-input" type="password" value={pwdInput}
            placeholder="Mot de passe"
            onChange={e=>setPwdInput(e.target.value)}
            onKeyDown={e=>e.key==='Enter'&&handleAdminLogin()}
            autoFocus/>
          {pwdError && <p style={{fontSize:12,color:C.red,marginBottom:12}}>{pwdError}</p>}
          <div style={{display:'flex',gap:10}}>
            <button className="btn btn-ghost" style={{flex:1}} onClick={()=>{setShowLogin(false);setPendingTab(null);}}>Annuler</button>
            <button className="btn btn-primary" style={{flex:2}} onClick={handleAdminLogin}>Accéder →</button>
          </div>
        </div>
      </div>

      <footer style={{borderTop:`1px solid ${C.border}`,padding:'20px 32px',display:'flex',alignItems:'center',gap:12,marginTop:40}}>
        <span style={{fontSize:11,color:C.dim,fontFamily:'Montserrat,sans-serif',fontWeight:500}}>
          Étude réalisée dans le cadre du programme UNamur · Tous droits réservés
        </span>
      </footer>
    </>
  );
}

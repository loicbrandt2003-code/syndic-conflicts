import SyndicApp from './SyndicApp';

export default function Home() {
  return <SyndicApp />;
}

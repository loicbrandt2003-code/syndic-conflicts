# Syndic Conflicts — Étude UNamur

Application Next.js avec base de données Vercel Postgres.

## Structure du projet

```
syndic-app/
├── app/
│   ├── api/
│   │   ├── responses/route.js   ← API pour sauvegarder les réponses
│   │   └── admin/route.js       ← API admin (lecture + suppression)
│   ├── SyndicApp.jsx            ← Toute l'interface (questionnaire + dashboard)
│   ├── layout.js
│   └── page.js
├── lib/
│   └── db.js                    ← Connexion base de données
├── .env.local                   ← Variables d'environnement (ne pas committer)
└── package.json
```

## Déploiement

### 1. Pousser sur GitHub
```bash
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/TON-USERNAME/syndic-conflicts.git
git push -u origin main
```

### 2. Déployer sur Vercel
1. Aller sur vercel.com → Add New Project → importer le repo
2. Vercel détecte automatiquement Next.js → cliquer Deploy

### 3. Ajouter la base de données
1. Dans le dashboard Vercel → ton projet → onglet "Storage"
2. Cliquer "Create Database" → choisir "Postgres"
3. Nommer la base (ex: syndic-db) → Create
4. Vercel connecte automatiquement les variables d'environnement

### 4. Ajouter le mot de passe admin
1. Dans Vercel → Settings → Environment Variables
2. Ajouter : ADMIN_PASSWORD = votre_mot_de_passe_secret
3. Redéployer (Deployments → Redeploy)

## Développement local

```bash
npm install
# Copier les variables Vercel Postgres dans .env.local
# (disponibles dans Vercel → Storage → Connect → .env.local)
npm run dev
```

## Mot de passe admin par défaut
Défini dans la variable d'environnement ADMIN_PASSWORD sur Vercel.
